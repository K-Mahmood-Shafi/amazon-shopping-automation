package com.amazon.tests;

import com.amazon.framework.base.BaseTest;
import com.amazon.framework.pages.CartPage;
import com.amazon.framework.pages.HomePage;
import com.amazon.framework.pages.ProductPage;
import com.amazon.framework.pages.SearchResultsPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class SearchAndAddToCartTest extends BaseTest {

    @Test
    public void verifyUserCanSearchProductAndAddToCart() {
        String productName = "wireless mouse";

        HomePage homePage = new HomePage(getDriver());
        SearchResultsPage resultsPage = homePage.searchForProduct(productName);

        Assert.assertTrue(resultsPage.isResultsDisplayed(),
                "Search results were not displayed for: " + productName);

        String firstResultTitle = resultsPage.getFirstResultTitle();
        System.out.println("First result: " + firstResultTitle);

        ProductPage productPage = resultsPage.clickFirstResult();

        String productPageTitle = productPage.getProductTitle();
        System.out.println("Product page title: " + productPageTitle);

        Assert.assertTrue(productPageTitle.toLowerCase().contains("mouse"),
                "Product title mismatch!");

        productPage.clickAddToCart();

        Assert.assertTrue(productPage.isAddedToCartMessageDisplayed(),
                "Add to cart confirmation message not displayed.");

        CartPage cartPage = productPage.goToCart();

        Assert.assertTrue(cartPage.isAnyItemPresentInCart(),
                "Item not found in cart after adding.");
    }
}
