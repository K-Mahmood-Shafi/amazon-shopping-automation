package com.amazon.framework.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class SearchResultsPage {

    private WebDriver driver;

    // Real Amazon search results
    private By searchResults = By.xpath("//div[@data-component-type='s-search-result']");
    private By firstProductLink = By.xpath("(//div[@data-component-type='s-search-result']//h2/a)[1]");
    private By firstProductTitleSpan = By.xpath("(//div[@data-component-type='s-search-result']//h2/a/span)[1]");

    public SearchResultsPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isResultsDisplayed() {
        return driver.findElements(searchResults).size() > 0;
    }

    public String getFirstResultTitle() {

        scrollToRealResults();

        By firstTitle = By.xpath("(//a[h2]/h2/span)[1]");

        WebElement title = new WebDriverWait(driver, Duration.ofSeconds(20))
                .until(ExpectedConditions.visibilityOfElementLocated(firstTitle));

        return title.getText();
    }


    public ProductPage clickFirstResult() {

        scrollToRealResults();

        By firstProductLink = By.xpath("(//a[h2])[1]");

        WebElement link = new WebDriverWait(driver, Duration.ofSeconds(20))
                .until(ExpectedConditions.elementToBeClickable(firstProductLink));

        // scroll to product card
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", link);

        // JavaScript click to avoid Amazon overlays and invisible element exceptions
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", link);

        return new ProductPage(driver);
    }


    private void scrollToRealResults() {
        // Scroll down so that real search results load
        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 800);");
    }
}
