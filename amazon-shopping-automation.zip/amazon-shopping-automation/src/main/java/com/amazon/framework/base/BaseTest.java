package com.amazon.framework.base;

import com.amazon.framework.utils.ConfigReader;
import com.amazon.framework.utils.WaitUtils;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import java.time.Duration;

public class BaseTest {

    protected static WebDriver driver;
    protected ConfigReader config;

    @BeforeSuite
    public void loadConfig() {
        config = new ConfigReader();
    }

    @BeforeMethod
    public void setUp() {

        WebDriverManager.firefoxdriver().setup();
        driver = new FirefoxDriver();

        driver.manage().window().maximize();

        driver.manage().timeouts().implicitlyWait(
                Duration.ofSeconds(Long.parseLong(config.getProperty("implicitWait"))));

        driver.manage().timeouts().pageLoadTimeout(
                Duration.ofSeconds(Long.parseLong(config.getProperty("pageLoadTimeout"))));

        driver.get(config.getProperty("baseUrl"));

        WaitUtils.setDriver(driver);
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    public WebDriver getDriver() {
        return driver;
    }
}
