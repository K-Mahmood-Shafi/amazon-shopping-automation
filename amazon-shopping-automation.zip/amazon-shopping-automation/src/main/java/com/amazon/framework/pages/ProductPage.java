package com.amazon.framework.pages;

import com.amazon.framework.utils.WaitUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.JavascriptExecutor;

public class ProductPage {

    private WebDriver driver;

    private By productTitle = By.id("productTitle");
    private By addToCartButton = By.id("add-to-cart-button");
    private By cartSuccessMessage = By.xpath("//h1[contains(text(),'Added to cart')]");


    public ProductPage(WebDriver driver) {
        this.driver = driver;
    }

    // 🟢 Switch to newly opened tab
    private void switchToNewTab() {
        for (String handle : driver.getWindowHandles()) {
            driver.switchTo().window(handle);
        }
    }

    public String getProductTitle() {

        // Switch to correct tab before reading title
        switchToNewTab();

        return WaitUtils.waitForElementVisible(productTitle, 15).getText().trim();
    }

    public void clickAddToCart() {

        switchToNewTab();  // 🟢 switch to product page tab
        
        // Scroll to button (sometimes needed)
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",
                WaitUtils.waitForElementVisible(addToCartButton, 20));

        // Click button safely
        WaitUtils.waitForElementClickable(addToCartButton, 20).click();
    }

    public boolean isAddedToCartMessageDisplayed() {
        try {
            WaitUtils.waitForElementVisible(cartSuccessMessage, 20);
            return true;
        } catch (Exception e) {
            return false;
        }
    }


    public CartPage goToCart() {
        driver.navigate().to("https://www.amazon.in/gp/cart/view.html");
        return new CartPage(driver);
    }
}
