package com.amazon.framework.pages;

import com.amazon.framework.utils.WaitUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {

    private WebDriver driver;

    private By searchBox = By.id("twotabsearchtextbox");
    private By searchButton = By.xpath("//input[@id='nav-search-submit-button' or @type='submit']");


    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterSearchText(String productName) {
        WebElement search = WaitUtils.waitForElementVisible(searchBox, 10);
        search.clear();
        search.sendKeys(productName);
    }

    public SearchResultsPage clickSearchButton() {
        WaitUtils.waitForElementClickable(searchButton, 10).click();
        return new SearchResultsPage(driver);
    }

    public SearchResultsPage searchForProduct(String productName) {
        enterSearchText(productName);
        return clickSearchButton();
    }
}
